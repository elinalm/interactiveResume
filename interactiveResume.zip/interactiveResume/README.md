# interactiveResume

Länk till Github: https://github.com/elinalm/interactiveResume

Länk till demo: https://elinalm.github.io/interactiveResume/.

Jag har gjort ett digitalt CV där fokus har 
varit på att hålla det hyfsat simpelt med mer fokus 
på en noga utvald bakgrund och val av färger. 

Bakgrunden är en illustration jag hittat på unsplash. 
inspirationen till min sida kommer från en illustratörs hemsida 
jag hittade: http://ellensriley.com/ 

På desktop-sidan har jag valt att ha kontaktuppgifter i footern 
som man når via en "contact"-knapp uppe till vänster. På
ipade-versionen och mobil-versionen finns de uppgifterna 
i en hamburgermeny istället. 

Min script-fil är ganska blandad när det kommer till att lösa händelser 
med hjälp av jquery eller bara vanlig javascript. Jag har valt att 
ha det kvar så för det var ändå en övning för mig själv också och 
kan vara bra att kunna kolla tillbaka på tänker jag. 


Jag har valt att ha tre css.filer för varje typ av device. 
I och med att jag inte hade så många funktioner i min javascript 
så valde jag att endast ha en script-fil. 